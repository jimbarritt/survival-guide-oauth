There are a number of Webapps in this directory.

Not all of them are valid.
But all of them are created by the jetty project.

The non-eclipse names present in the various webapps, for classes, packages, etc.
Are used for testcase reasons, and are all dummy implementations.

See the /jetty-webapp-verifier-examples/ project tree in source control for the
projects that built these webapps, and their respective WEB-INF/lib jars.
